import express from "express";
import { PackageMenu } from "../models/packageMenuModel.js";

const router = express.Router();

// Route for Save a new Book
router.post("/", async (request, response) => {
  try {
    const newHall = request.body;
    const hall = await PackageMenu.create(newHall);
    return response.status(201).send(hall);
  } catch (error) {
    console.log(error.message);
    response.status(500).send({ message: error.message });
  }
});

// Route for Get All Books from database
router.get("/", async (request, response) => {
  try {
    const halls = await PackageMenu.find({});
    return response.status(200).json({
      count: halls.length,
      data: halls,
    });
  } catch (error) {
    console.log(error.message);
    response.status(500).send({ message: error.message });
  }
});

// Route for Get One Book from database by id
router.get("/:id", async (request, response) => {
  try {
    const { id } = request.params;
    const hall = await PackageMenu.findById(id);
    if (!hall) {
      return response.status(404).json({ message: "Hall not found" });
    }
    return response.status(200).json(hall);
  } catch (error) {
    console.log(error.message);
    response.status(500).send({ message: error.message });
  }
});

// Route for Update a Book
router.put("/:id", async (request, response) => {
  try {
    const { id } = request.params;
    const updateHall = request.body;
    const result = await PackageMenu.findByIdAndUpdate(id, updateHall, {
      new: true,
    });
    if (!result) {
      return response.status(404).json({ message: "Hall not found" });
    }
    return response
      .status(200)
      .json({ message: "Hall updated successfully", data: result });
  } catch (error) {
    console.log(error.message);
    response.status(500).send({ message: error.message });
  }
});

// Route for Delete a book
// router.delete("/:id", async (request, response) => {
//   try {
//     const { id } = request.params;
//     const result = await Book.findByIdAndDelete(id);
//     if (!result) {
//       return response.status(404).json({ message: "Book not found" });
//     }
//     return response.status(200).json({ message: "Book deleted successfully" });
//   } catch (error) {
//     console.log(error.message);
//     response.status(500).send({ message: error.message });
//   }
// });

export default router;
