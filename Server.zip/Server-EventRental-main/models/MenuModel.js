import mongoose from "mongoose";

const menuSchema = mongoose.Schema(
  {
    FoodName: {
      type: String,
    },
    FoodCategory: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

export const Menu = mongoose.model("Menu", menuSchema);
