import mongoose from "mongoose";

const packageschema = mongoose.Schema(
  {
    packageName: {
      type: String,
    },
    pricePerPlate: {
      type: Number,
    },
  },
  {
    timestamps: true,
  }
);

export const Package = mongoose.model("Packages", packageschema);
