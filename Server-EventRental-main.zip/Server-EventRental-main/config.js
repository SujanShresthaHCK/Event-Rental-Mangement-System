export const PORT = 9000;

export const URL =
  "mongodb+srv://sujanshrestha:asxce||0@event-rental-management.g3hzygn.mongodb.net/user-data?retryWrites=true&w=majority&appName=Event-Rental-Management-System";
