import mongoose from "mongoose";

const bookSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: false,
    },
    phoneNo: {
      type: String,
      required: false,
    },
    price: {
      type: Number,
      default: 0,
    },
    email: {
      type: String,
      required: false,
    },
    eventType: {
      type: String,
      required: false,
    },
    hallName: {
      type: String,
      required: false,
    },
    estimatedGuests: {
      type: Number,
      required: false,
    },
    noofDays: {
      type: Number,
      required: false,
    },
    buffet: {
      type: String,
      required: false,
    },
    days: {
      type: String,
      required: false,
    },
    bookDate: {
      type: String,
      required: false,
    },
    dayShift: {
      type: String,
      required: false,
    },
    startDate: {
      type: String,
      required: false,
    },
    endDate: {
      type: String,
      required: false,
    },
    duration: {
      type: String,
      required: false,
    },
    checkedOut: {
      type: Boolean,
      default: false,
    },
    confirmed: {
      type: Boolean,
      default: false,
    },
    eventStatus: {
      type: Boolean,
    },
  },
  {
    timestamps: true,
  }
);

export const Book = mongoose.model("User", bookSchema);
