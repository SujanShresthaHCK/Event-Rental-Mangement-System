import mongoose from "mongoose";

const packageMenuSchema = mongoose.Schema(
  {
    FoodName: {
      type: String,
    },
    Package: {
      type: String,
    },
  },
  {
    timestamps: true,
  }
);

export const PackageMenu = mongoose.model("MenuPackage", packageMenuSchema);
