import mongoose from "mongoose";

const hallSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: false,
    },
    minCapacity: {
      type: String,
    },
    maxCapacity: {
      type: String,
    },
    priceShift: {
      type: Number,
    },
    priceDay: {
      type: Number,
    },
  },
  {
    timestamps: true,
  }
);

export const Hall = mongoose.model("EventHall", hallSchema);
